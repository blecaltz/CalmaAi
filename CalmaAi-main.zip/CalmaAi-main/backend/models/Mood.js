const mongoose = require("mongoose");

const NoteSchema = new mongoose.Schema({
  text: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: Date
}, { _id: true });

const MoodSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  mood: { type: String, default: "" }, // e.g. "Ansioso", "Feliz"
  notes: [NoteSchema],
  date: { type: Date, required: true } // date normalized to that day
}, { timestamps: true });

module.exports = mongoose.model("Mood", MoodSchema);
