import express from "express";
import mongoose from "mongoose";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import cors from "cors";
import dotenv from "dotenv";
import { GoogleGenerativeAI } from "@google/generative-ai";

import User from "./models/User.js";
import Mood from "./models/Mood.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(cors());

// 🔗 Conectar ao MongoDB
mongoose.connect(process.env.DB_CONNECTION_STRING)
  .then(() => console.log("✅ MongoDB conectado!"))
  .catch(err => console.error("❌ Erro Mongo:", err));

// 🔑 Middleware de autenticação
function auth(req, res, next) {
  const authHeader = req.headers["authorization"];
  if (!authHeader) return res.status(401).json({ message: "Token não fornecido!" });

  const token = authHeader.split(" ")[1];
  if (!token) return res.status(401).json({ message: "Token inválido!" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch {
    return res.status(401).json({ message: "Token expirado ou inválido!" });
  }
}

// 🤖 Configurar Gemini
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

// =================== ROTAS ===================

// Registrar usuário
app.post("/api/register", async (req, res) => {
  const { name, email, password } = req.body;
  const existe = await User.findOne({ email });
  if (existe) return res.status(400).json({ message: "E-mail já cadastrado!" });

  const hash = await bcrypt.hash(password, 10);
  const novoUser = new User({ name, email, password: hash });
  await novoUser.save();

  res.json({ message: "Usuário cadastrado com sucesso!" });
});

// Login
app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });
  if (!user) return res.status(401).json({ message: "E-mail ou senha incorretos!" });

  const senhaValida = await bcrypt.compare(password, user.password);
  if (!senhaValida) return res.status(401).json({ message: "E-mail ou senha incorretos!" });

  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" });

  res.json({ token, userId: user._id, name: user.name, email: user.email });
});

// Buscar perfil
app.get("/api/profile", auth, async (req, res) => {
  const user = await User.findById(req.userId).select("name email");
  res.json(user);
});

// Atualizar perfil
app.post("/api/update-profile", auth, async (req, res) => {
  const { name, currentPassword, newPassword } = req.body;
  const user = await User.findById(req.userId);
  if (!user) return res.status(400).json({ message: "Usuário não encontrado!" });

  if (name) user.name = name;

  if (currentPassword && newPassword) {
    const senhaValida = await bcrypt.compare(currentPassword, user.password);
    if (!senhaValida) return res.status(400).json({ message: "Senha atual incorreta!" });
    user.password = await bcrypt.hash(newPassword, 10);
  }

  await user.save();
  res.json({ message: "Perfil atualizado!" });
});

// =================== ROTAS DE NOTAS ===================

// Criar nota
app.post("/api/moods", auth, async (req, res) => {
  try {
    const { mood, note } = req.body;
    const novaNota = new Mood({ userId: req.userId, mood, note });
    await novaNota.save();
    res.json(novaNota);
  } catch (err) {
    res.status(500).json({ error: "Erro ao salvar nota" });
  }
});

// Listar notas do usuário
app.get("/api/moods", auth, async (req, res) => {
  try {
    const notas = await Mood.find({ userId: req.userId }).sort({ createdAt: -1 });
    res.json(notas);
  } catch (err) {
    res.status(500).json({ error: "Erro ao buscar notas" });
  }
});

// Atualizar nota
app.put("/api/moods/:id", auth, async (req, res) => {
  try {
    const { mood, note } = req.body;
    const nota = await Mood.findOneAndUpdate(
      { _id: req.params.id, userId: req.userId },
      { mood, note },
      { new: true }
    );
    if (!nota) return res.status(404).json({ message: "Nota não encontrada" });
    res.json(nota);
  } catch (err) {
    res.status(500).json({ error: "Erro ao atualizar nota" });
  }
});

// Deletar nota
app.delete("/api/moods/:id", auth, async (req, res) => {
  try {
    const nota = await Mood.findOneAndDelete({ _id: req.params.id, userId: req.userId });
    if (!nota) return res.status(404).json({ message: "Nota não encontrada" });
    res.json({ message: "Nota removida com sucesso" });
  } catch (err) {
    res.status(500).json({ error: "Erro ao excluir nota" });
  }
});

// =================== CHAT GEMINI ===================
app.post("/api/chat", async (req, res) => {
  try {
    const { message } = req.body;
    const result = await model.generateContent(message);
    res.json({ reply: result.response.text() });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao comunicar com o Gemini" });
  }
});

// =================== INICIAR SERVIDOR ===================
app.listen(PORT, () => console.log(`🚀 Servidor rodando em http://localhost:${PORT}`));
