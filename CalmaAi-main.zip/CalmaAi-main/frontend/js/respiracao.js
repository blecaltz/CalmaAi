const instruction = document.getElementById("instruction");
const circle = document.querySelector(".circle");
let breathing = false;
let timer;

// Função genérica para ciclos de respiração
function runBreathing(cycles, cycleTime) {
  let elapsed = 0;
  function next() {
    if (elapsed >= 60) {
      stopBreathing();
      return;
    }
    let step = cycles.shift();
    instruction.textContent = step.text;
    circle.style.transform = step.scale ? "scale(1.5)" : "scale(1)";
    setTimeout(() => {
      cycles.push(step);
      elapsed += step.time;
      next();
    }, step.time * 1000);
  }
  next();
}

// Métodos de respiração
function startBreathing(type) {
  breathing = true;
  clearTimeout(timer);

  switch (type) {
    case "constant": // 4-4-4
      runBreathing([
        { text: "Inspire (4s)", time: 4, scale: true },
        { text: "Segure (4s)", time: 4, scale: true },
        { text: "Expire (4s)", time: 4, scale: false }
      ], 12);
      break;

    case "box": // 4-4-4-4
      runBreathing([
        { text: "Inspire (4s)", time: 4, scale: true },
        { text: "Segure cheio (4s)", time: 4, scale: true },
        { text: "Expire (4s)", time: 4, scale: false },
        { text: "Segure vazio (4s)", time: 4, scale: false }
      ], 16);
      break;

    case "478": // 4-7-8
      runBreathing([
        { text: "Inspire (4s)", time: 4, scale: true },
        { text: "Segure (7s)", time: 7, scale: true },
        { text: "Expire (8s)", time: 8, scale: false }
      ], 19);
      break;

    case "resonant": // 6 ciclos/min ~ respiração ressoante
      runBreathing([
        { text: "Inspire (5s)", time: 5, scale: true },
        { text: "Expire (5s)", time: 5, scale: false }
      ], 10);
      break;
  }
}

// Parar
function stopBreathing() {
  breathing = false;
  instruction.textContent = "Exercício finalizado!";
  circle.style.transform = "scale(1)";
}

// Voltar ao menu
function backToMenu() {
  stopBreathing();
  instruction.textContent = "Selecione um exercício";
}
